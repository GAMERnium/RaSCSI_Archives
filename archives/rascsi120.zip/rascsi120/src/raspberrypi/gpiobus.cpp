﻿//---------------------------------------------------------------------------
//
//  SCSI Target Emulator RaSCSI (*^..^*)
//  for Raspberry Pi
//
//  Powered by XM6 TypeG Technorogy.
//  Copyright (C) 2016-2017 GIMONS
//	[ GPIO-SCSIバス ]
//
//---------------------------------------------------------------------------

#include "os.h"
#include "xm6.h"
#include "fileio.h"
#include "filepath.h"
#include "disk.h"
#include "gpiobus.h"

//---------------------------------------------------------------------------
//
//	コンストラクタ
//
//---------------------------------------------------------------------------
GPIOBUS::GPIOBUS()
{
}

//---------------------------------------------------------------------------
//
//	デストラクタ
//
//---------------------------------------------------------------------------
GPIOBUS::~GPIOBUS()
{
}

//---------------------------------------------------------------------------
//
//	初期化
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::Init()
{
	int i;
	int j;
	DWORD busdata;
	DWORD seldata;
	DWORD parity;

	// GPIO初期化
	if (!GpioInit()) {
		return FALSE;
	}

	// GPIO Drive Strengthを16mAに設定
	DrvConfig(7);

	// GPIOピン設定(入出力)を全て入力に設定
	PinConfig(pin_dt0, GPIO_INPUT);
	PinConfig(pin_dt1, GPIO_INPUT);
	PinConfig(pin_dt2, GPIO_INPUT);
	PinConfig(pin_dt3, GPIO_INPUT);
	PinConfig(pin_dt4, GPIO_INPUT);
	PinConfig(pin_dt5, GPIO_INPUT);
	PinConfig(pin_dt6, GPIO_INPUT);
	PinConfig(pin_dt7, GPIO_INPUT);
	PinConfig(pin_par, GPIO_INPUT);
	PinConfig(pin_atn, GPIO_INPUT);
	PinConfig(pin_bsy, GPIO_INPUT);
	PinConfig(pin_ack, GPIO_INPUT);
	PinConfig(pin_rst, GPIO_INPUT);
	PinConfig(pin_msg, GPIO_INPUT);
	PinConfig(pin_sel, GPIO_INPUT);
	PinConfig(pin_cd,  GPIO_INPUT);
	PinConfig(pin_req, GPIO_INPUT);
	PinConfig(pin_io,  GPIO_INPUT);

	// GPIOピン設定(プルアップ/プルダウン)を無しに設定
	PullConfig(pin_dt0, GPIO_PULLNONE);
	PullConfig(pin_dt1, GPIO_PULLNONE);
	PullConfig(pin_dt2, GPIO_PULLNONE);
	PullConfig(pin_dt3, GPIO_PULLNONE);
	PullConfig(pin_dt4, GPIO_PULLNONE);
	PullConfig(pin_dt5, GPIO_PULLNONE);
	PullConfig(pin_dt6, GPIO_PULLNONE);
	PullConfig(pin_dt7, GPIO_PULLNONE);
	PullConfig(pin_par, GPIO_PULLNONE);
	PullConfig(pin_atn, GPIO_PULLNONE);
	PullConfig(pin_bsy, GPIO_PULLNONE);
	PullConfig(pin_ack, GPIO_PULLNONE);
	PullConfig(pin_rst, GPIO_PULLNONE);
	PullConfig(pin_msg, GPIO_PULLNONE);
	PullConfig(pin_sel, GPIO_PULLNONE);
	PullConfig(pin_cd,  GPIO_PULLNONE);
	PullConfig(pin_req, GPIO_PULLNONE);
	PullConfig(pin_io,  GPIO_PULLNONE);

	// GPIOピン設定(出力値)をローレベルに設定
	PinSigSet(pin_dt0, FALSE);
	PinSigSet(pin_dt1, FALSE);
	PinSigSet(pin_dt2, FALSE);
	PinSigSet(pin_dt3, FALSE);
	PinSigSet(pin_dt4, FALSE);
	PinSigSet(pin_dt5, FALSE);
	PinSigSet(pin_dt6, FALSE);
	PinSigSet(pin_dt7, FALSE);
	PinSigSet(pin_par, FALSE);
	PinSigSet(pin_atn, FALSE);
	PinSigSet(pin_bsy, FALSE);
	PinSigSet(pin_ack, FALSE);
	PinSigSet(pin_rst, FALSE);
	PinSigSet(pin_msg, FALSE);
	PinSigSet(pin_sel, FALSE);
	PinSigSet(pin_cd, FALSE);
	PinSigSet(pin_req, FALSE);
	PinSigSet(pin_io, FALSE);

	// GPFSELバックアップ
	dwGPFSEL[0] = gpio[GPIO_FSEL_0];
	dwGPFSEL[1] = gpio[GPIO_FSEL_1];
	dwGPFSEL[2] = gpio[GPIO_FSEL_2];
	dwGPFSEL[3] = gpio[GPIO_FSEL_3];

	// データバス → GPIO設定データテーブル作成
	for (i = 0; i < 0x100; i++) {
		busdata = (DWORD)i;
		seldata = 0;
		parity = 0;
		for (j = 0; j < 8; j++) {
			seldata |= (busdata & 1) << (3 * j);
			parity ^= busdata & 1;
			busdata >>= 1;
		}
		parity = (parity & 1) ? 0 : 1 << (3 * 8);

		tblDataBus[i] = parity | seldata;
	}

	return TRUE;
}

//---------------------------------------------------------------------------
//
//	リセット
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::Reset()
{
	// GPIOピン設定(入出力)を全て入力に設定
	PinConfig(pin_dt0, GPIO_INPUT);
	PinConfig(pin_dt1, GPIO_INPUT);
	PinConfig(pin_dt2, GPIO_INPUT);
	PinConfig(pin_dt3, GPIO_INPUT);
	PinConfig(pin_dt4, GPIO_INPUT);
	PinConfig(pin_dt5, GPIO_INPUT);
	PinConfig(pin_dt6, GPIO_INPUT);
	PinConfig(pin_dt7, GPIO_INPUT);
	PinConfig(pin_par, GPIO_INPUT);
	PinConfig(pin_atn, GPIO_INPUT);
	PinConfig(pin_bsy, GPIO_INPUT);
	PinConfig(pin_ack, GPIO_INPUT);
	PinConfig(pin_rst, GPIO_INPUT);
	PinConfig(pin_msg, GPIO_INPUT);
	PinConfig(pin_sel, GPIO_INPUT);
	PinConfig(pin_cd,  GPIO_INPUT);
	PinConfig(pin_req, GPIO_INPUT);
	PinConfig(pin_io,  GPIO_INPUT);

	// GPIOピン設定(プルアップ/プルダウン)を無しに設定
	PullConfig(pin_dt0, GPIO_PULLNONE);
	PullConfig(pin_dt1, GPIO_PULLNONE);
	PullConfig(pin_dt2, GPIO_PULLNONE);
	PullConfig(pin_dt3, GPIO_PULLNONE);
	PullConfig(pin_dt4, GPIO_PULLNONE);
	PullConfig(pin_dt5, GPIO_PULLNONE);
	PullConfig(pin_dt6, GPIO_PULLNONE);
	PullConfig(pin_dt7, GPIO_PULLNONE);
	PullConfig(pin_par, GPIO_PULLNONE);
	PullConfig(pin_atn, GPIO_PULLNONE);
	PullConfig(pin_bsy, GPIO_PULLNONE);
	PullConfig(pin_ack, GPIO_PULLNONE);
	PullConfig(pin_rst, GPIO_PULLNONE);
	PullConfig(pin_msg, GPIO_PULLNONE);
	PullConfig(pin_sel, GPIO_PULLNONE);
	PullConfig(pin_cd,  GPIO_PULLNONE);
	PullConfig(pin_req, GPIO_PULLNONE);
	PullConfig(pin_io,  GPIO_PULLNONE);

	// GPIOピン設定(出力値)をローレベルに設定
	PinSigSet(pin_dt0, FALSE);
	PinSigSet(pin_dt1, FALSE);
	PinSigSet(pin_dt2, FALSE);
	PinSigSet(pin_dt3, FALSE);
	PinSigSet(pin_dt4, FALSE);
	PinSigSet(pin_dt5, FALSE);
	PinSigSet(pin_dt6, FALSE);
	PinSigSet(pin_dt7, FALSE);
	PinSigSet(pin_par, FALSE);
	PinSigSet(pin_atn, FALSE);
	PinSigSet(pin_bsy, FALSE);
	PinSigSet(pin_ack, FALSE);
	PinSigSet(pin_rst, FALSE);
	PinSigSet(pin_msg, FALSE);
	PinSigSet(pin_sel, FALSE);
	PinSigSet(pin_cd, FALSE);
	PinSigSet(pin_req, FALSE);
	PinSigSet(pin_io, FALSE);

	// GPFSELバックアップ
	dwGPFSEL[0] = gpio[GPIO_FSEL_0];
	dwGPFSEL[1] = gpio[GPIO_FSEL_1];
	dwGPFSEL[2] = gpio[GPIO_FSEL_2];
	dwGPFSEL[3] = gpio[GPIO_FSEL_3];

	signals = 0xffffffff;
}

//---------------------------------------------------------------------------
//
//	クリーンアップ
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::Cleanup()
{
	// GPIOピン設定(入出力)を全て入力に設定
	PinConfig(pin_dt0, GPIO_INPUT);
	PinConfig(pin_dt1, GPIO_INPUT);
	PinConfig(pin_dt2, GPIO_INPUT);
	PinConfig(pin_dt3, GPIO_INPUT);
	PinConfig(pin_dt4, GPIO_INPUT);
	PinConfig(pin_dt5, GPIO_INPUT);
	PinConfig(pin_dt6, GPIO_INPUT);
	PinConfig(pin_dt7, GPIO_INPUT);
	PinConfig(pin_par, GPIO_INPUT);
	PinConfig(pin_atn, GPIO_INPUT);
	PinConfig(pin_bsy, GPIO_INPUT);
	PinConfig(pin_ack, GPIO_INPUT);
	PinConfig(pin_rst, GPIO_INPUT);
	PinConfig(pin_msg, GPIO_INPUT);
	PinConfig(pin_sel, GPIO_INPUT);
	PinConfig(pin_cd,  GPIO_INPUT);
	PinConfig(pin_req, GPIO_INPUT);
	PinConfig(pin_io,  GPIO_INPUT);

	// GPIOピン設定(プルアップ/プルダウン)を無しに設定
	PullConfig(pin_dt0, GPIO_PULLNONE);
	PullConfig(pin_dt1, GPIO_PULLNONE);
	PullConfig(pin_dt2, GPIO_PULLNONE);
	PullConfig(pin_dt3, GPIO_PULLNONE);
	PullConfig(pin_dt4, GPIO_PULLNONE);
	PullConfig(pin_dt5, GPIO_PULLNONE);
	PullConfig(pin_dt6, GPIO_PULLNONE);
	PullConfig(pin_dt7, GPIO_PULLNONE);
	PullConfig(pin_par, GPIO_PULLNONE);
	PullConfig(pin_atn, GPIO_PULLNONE);
	PullConfig(pin_bsy, GPIO_PULLNONE);
	PullConfig(pin_ack, GPIO_PULLNONE);
	PullConfig(pin_rst, GPIO_PULLNONE);
	PullConfig(pin_msg, GPIO_PULLNONE);
	PullConfig(pin_sel, GPIO_PULLNONE);
	PullConfig(pin_cd,  GPIO_PULLNONE);
	PullConfig(pin_req, GPIO_PULLNONE);
	PullConfig(pin_io,  GPIO_PULLNONE);

	// GPIOピン設定(出力値)をローレベルに設定
	PinSigSet(pin_dt0, FALSE);
	PinSigSet(pin_dt1, FALSE);
	PinSigSet(pin_dt2, FALSE);
	PinSigSet(pin_dt3, FALSE);
	PinSigSet(pin_dt4, FALSE);
	PinSigSet(pin_dt5, FALSE);
	PinSigSet(pin_dt6, FALSE);
	PinSigSet(pin_dt7, FALSE);
	PinSigSet(pin_par, FALSE);
	PinSigSet(pin_atn, FALSE);
	PinSigSet(pin_bsy, FALSE);
	PinSigSet(pin_ack, FALSE);
	PinSigSet(pin_rst, FALSE);
	PinSigSet(pin_msg, FALSE);
	PinSigSet(pin_sel, FALSE);
	PinSigSet(pin_cd, FALSE);
	PinSigSet(pin_req, FALSE);
	PinSigSet(pin_io, FALSE);

	// GPIO Drive Strengthを8mAに設定
	DrvConfig(3);
}

//---------------------------------------------------------------------------
//
//	GPIO初期化
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GpioInit()
{
	FILE *file;
	char line[256]; 
	char hardware[256];
	off_t base;
	int fd;
	void *map;

	// CPU情報を取得
	file = fopen("/proc/cpuinfo", "r");
	if (!file) {
		return FALSE;
	}
   
	// Hardwareで始まる行を探す
	memset(hardware, 0x00, sizeof(hardware));
	while (fgets(line, 256, file)) {
		if (strncmp(line, "Hardware", 8) == 0) {
			strcpy(hardware, strchr(line, ':') + 2);
		}
	}
	fclose(file);

	// モデル別にベースアドレスを決定
	hardware[strlen(hardware) - 1] = 0x00;
	if (strncmp(hardware, "BCM2708", 7) == 0) {
		// Raspberry Pi 1 or Zero
		base = PERI_BASE1;
		//printf("Raspberry Pi1 or Zero\n\n");
	} else {
		// Raspberry Pi 2 or 3
		base = PERI_BASE2;
		//printf("Raspberry Pi2 or 3\n");
	}

	// /dev/memをオープン
	fd = open("/dev/mem", O_RDWR | O_SYNC);
	if (fd == -1) {
		return FALSE;
	}

	// GPIOのI/Oポートをマップする
	map = mmap(NULL, GBLOCK_SIZE,
		PROT_READ | PROT_WRITE, MAP_SHARED, fd, base + GPIO_OFFSET);
	if (map == MAP_FAILED) {
		close(fd);
		return FALSE;
	}

	// GPIOのI/Oポートアドレス確保
	gpio = (DWORD *)map;

	// PADSのI/Oポートをマップする
	map = mmap(NULL, GBLOCK_SIZE,
		PROT_READ | PROT_WRITE, MAP_SHARED, fd, base + PADS_OFFSET);
	if (map == MAP_FAILED) {
		close(fd);
		return FALSE;
	}

	// PADSのI/Oポートアドレス確保
	pads = (DWORD *)map;

	// クローズ
	close(fd);

	return TRUE;
}

//---------------------------------------------------------------------------
//
//	ピン機能設定(入出力設定)
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::PinConfig(pin_t pin, int mode)
{
	int index;
	DWORD mask;

	index = pin / 10;
	mask = ~(0x7 << ((pin % 10) * 3));
    gpio[index] = (gpio[index] & mask) | ((mode & 0x7) << ((pin % 10) * 3));
}

//---------------------------------------------------------------------------
//
//	ピン機能設定(プルアップ/ダウン)
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::PullConfig (pin_t pin, int mode)
{
    gpio[GPIO_PUD] = mode & 0x3;
    usleep(1);
    gpio[GPIO_CLK_0] = 0x1 << pin;
    usleep(1);
    gpio[GPIO_PUD] = 0;
    gpio[GPIO_CLK_0] = 0;
}

//---------------------------------------------------------------------------
//
//	Drive Strength設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::DrvConfig(DWORD drive)
{
	DWORD data;

	data = pads[PAD_0_27];
	pads[PAD_0_27] = (0xFFFFFFF8 & data) | drive | 0x5a000000;
}

//---------------------------------------------------------------------------
//
//	ピン出力設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::PinSigSet(pin_t pin, BOOL assert)
{
	if (assert) {
		gpio[GPIO_SET_0] = 0x1 << pin;
	} else {
	    gpio[GPIO_CLR_0] = 0x1 << pin;
	}
}

//---------------------------------------------------------------------------
//
//	ナノ秒単位のスリープ(精度は60ns程度)
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SleepNsec(long nsec)
{
	long count;
	volatile DWORD wait;

	count = (nsec + 60 - 1) / 60;
	while (count--) {
		wait = gpio[GPIO_FSEL_1];
	}
}

//---------------------------------------------------------------------------
//
//	バス信号取り込み
//
//---------------------------------------------------------------------------
DWORD FASTCALL GPIOBUS::Aquire()
{
	signals = (DWORD)gpio[GPIO_LEV_0];
	return signals;
}

//---------------------------------------------------------------------------
//
//	BSYシグナル取得
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GetBSY()
{
	return GetSignal(pin_bsy);
}

//---------------------------------------------------------------------------
//
//	BSYシグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetBSY(BOOL ast)
{
	SetSignal(pin_bsy, ast);
}

//---------------------------------------------------------------------------
//
//	SELシグナル取得
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GetSEL()
{
	return GetSignal(pin_sel);
}

//---------------------------------------------------------------------------
//
//	SELシグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetSEL(BOOL ast)
{
	SetSignal(pin_sel, ast);
}

//---------------------------------------------------------------------------
//
//	ATNシグナル取得
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GetATN()
{
	return GetSignal(pin_atn);
}

//---------------------------------------------------------------------------
//
//	ATNシグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetATN(BOOL ast)
{
	SetSignal(pin_atn, ast);
}

//---------------------------------------------------------------------------
//
//	ACKシグナル取得
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GetACK()
{
	return GetSignal(pin_ack);
}

//---------------------------------------------------------------------------
//
//	ACKシグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetACK(BOOL ast)
{
	SetSignal(pin_ack, ast);
}

//---------------------------------------------------------------------------
//
//	RSTシグナル取得
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GetRST()
{
	return GetSignal(pin_rst);
}

//---------------------------------------------------------------------------
//
//	RSTシグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetRST(BOOL ast)
{
	SetSignal(pin_rst, ast);
}

//---------------------------------------------------------------------------
//
//	MSGシグナル取得
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GetMSG()
{
	return GetSignal(pin_msg);
}

//---------------------------------------------------------------------------
//
//	MSGシグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetMSG(BOOL ast)
{
	SetSignal(pin_msg, ast);
}

//---------------------------------------------------------------------------
//
//	CDシグナル取得
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GetCD()
{
	return GetSignal(pin_cd);
}

//---------------------------------------------------------------------------
//
//	CDシグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetCD(BOOL ast)
{
	SetSignal(pin_cd, ast);
}

//---------------------------------------------------------------------------
//
//	IOシグナル取得
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GetIO()
{
	return GetSignal(pin_io);
}

//---------------------------------------------------------------------------
//
//	IOシグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetIO(BOOL ast)
{
	SetSignal(pin_io, ast);

	// IOがイニシエータからターゲットなのでデータを入力に変更
	if (!ast) {
		gpio[GPIO_FSEL_1] = 0;
	}
}

//---------------------------------------------------------------------------
//
//	REQシグナル取得
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GetREQ()
{
	return GetSignal(pin_req);
}

//---------------------------------------------------------------------------
//
//	REQシグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetREQ(BOOL ast)
{
	SetSignal(pin_req, ast);
}

//---------------------------------------------------------------------------
//
//	データシグナル取得
//
//---------------------------------------------------------------------------
BYTE FASTCALL GPIOBUS::GetDAT()
{
	return  (~signals >> pin_dt0) & 0xff;
}

//---------------------------------------------------------------------------
//
//	データシグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetDAT(BYTE dat)
{
	gpio[GPIO_FSEL_1] = tblDataBus[dat];

	// ダミーのウェイト(何故か少しウェイトを入れないとダメ200ns相当)
	SleepNsec(200);
}

//---------------------------------------------------------------------------
//
//	シグナル取得
//
//---------------------------------------------------------------------------
BOOL FASTCALL GPIOBUS::GetSignal(pin_t sig)
{
	return  (signals & (1 << sig)) ? FALSE : TRUE;
}

//---------------------------------------------------------------------------
//
//	シグナル設定
//
//---------------------------------------------------------------------------
void FASTCALL GPIOBUS::SetSignal(pin_t sig, BOOL ast)
{
	dwGPFSEL[GPIO_FSEL_2] &= ~(0x7 << ((sig % 10) * 3));
	if (ast) {
		dwGPFSEL[GPIO_FSEL_2] |= (1 << ((sig % 10) * 3));
	}
	gpio[GPIO_FSEL_2] = dwGPFSEL[GPIO_FSEL_2];
}
