//---------------------------------------------------------------------------
//
//  SCSI Target Emulator RaSCSI (*^..^*)
//  for Raspberry Pi
//
//  Powered by XM6 TypeG Technorogy.
//  Copyright (C) 2016-2017 GIMONS
//	[ メイン ]
//
//---------------------------------------------------------------------------

#include "os.h"
#include "xm6.h"
#include "fileio.h"
#include "filepath.h"
#include "disk.h"
#include "gpiobus.h"

//---------------------------------------------------------------------------
//
//	変数宣言
//
//---------------------------------------------------------------------------
enum {
	CtrlMax = 8,					// 最大SCSIコントローラ数
};

SCSIDEV *ctrl[CtrlMax];				// SCSIコントローラ
Disk *hd[CtrlMax];					// HD/MO/CD
Filepath scsihd[CtrlMax];			// SCSI-HDファイルパス
GPIOBUS bus;						// バス
BUS::phase_t phase;					// フェーズ
int scsiid;							// アクティブなSCSIID
volatile BOOL bRun;					// 実行中フラグ

BOOL bServer;						// サーバーモードフラグ
int monfd;							// モニター用ソケットFD
pthread_t monthread;				// モニタースレッド
static void *MonThread(void *param);

//---------------------------------------------------------------------------
//
//	シグナル処理
//
//---------------------------------------------------------------------------
void KillHandler(int sig)
{
	// 停止指示
	bRun = FALSE;
}

//---------------------------------------------------------------------------
//
//	バナー出力
//
//---------------------------------------------------------------------------
BOOL Banner(int argc, char* argv[])
{
	printf("SCSI Target Emulator RaSCSI(*^..^*) ");
	printf("version %01d.%01d%01d for Raspberry Pi \n",
		(int)((RASCSI >> 8) & 0xf),
		(int)((RASCSI >> 4) & 0xf),
		(int)((RASCSI     ) & 0xf));
	printf("Powered by XM6 TypeG Technorogy / ");
	printf("Copyright (C) 2016-2017 GIMONS\n");

	if (argc > 1 && strcmp(argv[1], "-h") == 0) {
		printf("\n");
		printf("Usage: %s [-ID{0|1|2|3|4|5|6|7} FILE] ...\n\n", argv[0]);
		printf(" ID is SCSI identification number.\n");
		printf(" FILE is disk image file.\n\n");
		printf(" Detected images type based on file extension.\n");
		printf("  hds : HD image\n");
		printf("  mos : MO image\n");
		printf("  iso : CD image\n");
		return FALSE;
	}

	return TRUE;
}

//---------------------------------------------------------------------------
//
//	初期化
//
//---------------------------------------------------------------------------
BOOL Init()
{
	int i;
	struct sockaddr_in server;

	// モニター用ソケット生成
	monfd = socket(PF_INET, SOCK_STREAM, 0);
	memset(&server, 0, sizeof(server));
	server.sin_family = PF_INET;
	server.sin_port   = htons(6868);
	server.sin_addr.s_addr = htonl(INADDR_ANY); 
	if (bind(monfd, (struct sockaddr *)&server,
		sizeof(struct sockaddr_in)) < 0) {
		if (errno != EADDRINUSE) {
			return FALSE;
		}
		bServer = FALSE;
		return TRUE;
	} else {
		bServer = TRUE;
	}

	// 割り込みハンドラ設定
	if (signal(SIGINT, KillHandler) == SIG_ERR) {
		return FALSE;
	}
	if (signal(SIGHUP, KillHandler) == SIG_ERR) {
		return FALSE;
	}
	if (signal(SIGTERM, KillHandler) == SIG_ERR) {
		return FALSE;
	}

	// GPIO初期化
	if (!bus.Init()) {
		return FALSE;
	}

	// コントローラ初期化
	for (i = 0; i < CtrlMax; i++) {
		ctrl[i] = NULL;
	}

	// ディスク初期化
	for (i = 0; i < CtrlMax; i++) {
		hd[i] = NULL;
	}

	// パス初期化
	for (i = 0; i < CtrlMax; i++) {
		scsihd[i].Clear();
	}

	// ID初期化
	scsiid = -1;

	return TRUE;
}

//---------------------------------------------------------------------------
//
//	クリーンアップ
//
//---------------------------------------------------------------------------
void Cleanup()
{
	int i;

	// HD削除
	for (i = 0; i < CtrlMax; i++) {
		if (hd[i]) {
			delete hd[i];
			hd[i] = NULL;
		}
	}

	// コントローラ削除
	for (i = 0; i < CtrlMax; i++) {
		if (ctrl[i]) {
			delete ctrl[i];
			ctrl[i] = NULL;
		}
	}

	// バスをクリーンアップ
	bus.Cleanup();

	// モニター用ソケットクローズ
	if (monfd >= 0) {
		close(monfd);
	}
}

//---------------------------------------------------------------------------
//
//	リセット
//
//---------------------------------------------------------------------------
void Reset()
{
	int i;

	// SCSIID
	scsiid = -1;

	// コントローラリセット
	for (i = 0; i < CtrlMax; i++) {
		if (ctrl[i]) {
			ctrl[i]->Reset();
		}
	}

	// バス信号線をリセット
	bus.Reset();
}

//---------------------------------------------------------------------------
//
//	デバイス一覧表示
//
//---------------------------------------------------------------------------
void ListDevice(FILE *fp)
{
	int i;
	Filepath filepath;
	BOOL find;
	char type[3];

	find = FALSE;
	type[2] = 0;
	for (i = 0; i < 8; i++) {
		if (hd[i] == NULL) {
			continue;
		}

		// ヘッダー出力
		if (!find) {
			fprintf(fp, "ID|TYPE|INSTALL STATUS\n");
			fprintf(fp, "--------------------------------------------------\n");
			find = TRUE;
		}

		// ID,タイプ出力
		type[0] = (char)(hd[i]->GetID() >> 8);
		type[1] = (char)(hd[i]->GetID());
		fprintf(fp, " %d| %s |", i, type);

		// マウント状態出力
		if (hd[i]->GetID() == MAKEID('S', 'C', 'E', 'T')) {
			fprintf(fp, "%s", "RaSCSI ETHER");
		} else if (hd[i]->GetID() == MAKEID('S', 'C', 'B', 'R')) {
			fprintf(fp, "%s", "RaSCSI BRIDGE");
		} else {
			hd[i]->GetPath(filepath);
			fprintf(fp, "%s",
				(hd[i]->IsRemovable() && !hd[i]->IsReady()) ?
				"NO MEDIA" : filepath.GetPath());
		}

		// ライトプロテクト状態出力
		if (hd[i]->IsRemovable() && hd[i]->IsReady() && hd[i]->IsWriteP()) {
			fprintf(fp, "(WRITEPROTECT)");
		}

		// 次の行へ
		fprintf(fp, "\n");
	}

	// コントローラが無い場合
	if (!find) {
		fprintf(fp, "No device is installed.\n");
	}
}

//---------------------------------------------------------------------------
//
//	コマンド処理
//
//---------------------------------------------------------------------------
BOOL ProcessCmd(FILE *fp, int id, int cmd, int type, char *file)
{
	Filepath filepath;

	// SCSI IDチェック
	if (id < 0 || id > 7) {
		fprintf(fp, "Error : Invalid SCSI ID\n");
		return FALSE;
	}

	// 接続コマンド
	if (cmd == 0) {					// ATTACH
		// コントローラを作る
		if (ctrl[id] == NULL) {
			ctrl[id] = new SCSIDEV();
			ctrl[id]->Connect(id, &bus);
		}

		// ディスクがあれば解放
		if (hd[id]) {
			ctrl[id]->SetUnit(0, NULL);
			delete hd[id];
			hd[id] = NULL;
		}

		// タイプ別のインスタンスを生成
		switch (type) {
			case 0:		// HDD
				hd[id] = new SCSIHD();
				break;
			case 1:		// MO
				hd[id] = new SCSIMO();
				break;
			case 2:		// CD
				hd[id] = new SCSICD();
				break;
			case 3:		// ETHER
				hd[id] = new SCSIET();
				break;
			case 4:		// BRIDGE
				hd[id] = new SCSIBR();
				break;
			default:
				delete ctrl[id];
				ctrl[id] = NULL;
				fprintf(fp,	"Error : Invalid device type\n");
				return FALSE;
		}

		// ドライブはファイルの確認を行う
		if (type < 3) {
			// パスを設定
			filepath.SetPath(file);

			// オープン
			if (!hd[id]->Open(filepath)) {
				fprintf(fp, "Error : File open error [%s]\n", file);
				delete hd[id];
				hd[id] = NULL;
				delete ctrl[id];
				ctrl[id] = NULL;
				return FALSE;
			}
		}

		// 新たなディスクを接続
		ctrl[id]->SetUnit(0, hd[id]);
		hd[id]->SetCacheWB(TRUE);
		return TRUE;
	}

	// 有効なコマンドか
	if (cmd > 4) {
		fprintf(fp, "Error : Invalid command\n");
		return FALSE;
	}

	// コントローラが存在するか
	if (ctrl[id] == NULL) {
		fprintf(fp, "Error : No such device\n");
		return FALSE;
	}

	// デバイスが存在するか
	if (hd[id] == NULL) {
		fprintf(fp, "Error : No such device\n");
		return FALSE;
	}

	// 切断コマンド
	if (cmd == 1) {					// DETACH
		ctrl[id]->SetUnit(0, NULL);
		delete hd[id];
		hd[id] = NULL;
		delete ctrl[id];
		ctrl[id] = NULL;
		return TRUE;
	}

	// MOかCDの場合だけ有効
	if (hd[id]->GetID() != MAKEID('S', 'C', 'M', 'O') &&
		hd[id]->GetID() != MAKEID('S', 'C', 'C', 'D')) {
		fprintf(fp, "Error : Operation denied(Deveice isn't MO or CD)\n");
		return FALSE;
	}

	switch (cmd) {
		case 2:						// INSERT
			// パスを設定
			filepath.SetPath(file);

			// オープン
			if (!hd[id]->Open(filepath)) {
				fprintf(fp, "Error : File open error [%s]\n", file);
				return FALSE;
			}
			break;

		case 3:						// EJECT
			hd[id]->Eject(TRUE);
			break;

		case 4:						// PROTECT
			if (hd[id]->GetID() != MAKEID('S', 'C', 'M', 'O')) {
				fprintf(fp, "Error : Operation denied(Deveice isn't MO)\n");
				return FALSE;
			}
			hd[id]->WriteP(!hd[id]->IsWriteP());
			break;
		default:
			ASSERT(FALSE);
			return FALSE;
	}

	return TRUE;
}

//---------------------------------------------------------------------------
//
//	引数処理
//
//---------------------------------------------------------------------------
BOOL ParseArgument(int argc, char* argv[])
{
	int i;
	int id;
	int type;
	char *argID;
	char *argPath;
	int len;
	char *ext;

	// IDとパス指定がなければ処理を中断
	if (argc < 3) {
		return TRUE;
	}

	// 引数の解読開始
	i = 1;
	argc--;

	// IDとパスを取得
	while (argc >= 2) {
		argc -= 2;
		argID = argv[i++];
		argPath = argv[i++];

		// -IDの形式をチェック
		if (strlen(argID) != 4 ||
			argID[0] != '-' || argID[1] != 'I' || argID[2] != 'D') {
			fprintf(stderr,
				"Error : Invalid argument(-IDn) [%s]\n", argID);
			return FALSE;
		}

		// ID番号をチェック(0-7)
		if (argID[3] < '0' || argID[3] > '7') {
			fprintf(stderr,
				"Error : Invalid argument(-IDn n=0-7) [%c]\n", argID[3]);
			return FALSE;
		}

		// ID確定
		id = argID[3] - '0';

		// すでにアクティブなデバイスがあるならスキップ
		if (hd[id]) {
			continue;
		}

		// デバイスタイプを初期化
		type = -1;

		// イーサネットとホストブリッジのチェック
		if (strcasecmp(argPath, "ether") == 0) {
			type = 3;
		} else if (strcasecmp(argPath, "bridge") == 0) {
			type = 4;
		} else {
			// パスの長さをチェック
			len = strlen(argPath);
			if (len < 5) {
				fprintf(stderr,
					"Error : Invalid argument(File path is short) [%s]\n",
					argPath);
				return FALSE;
			}

			// 拡張子を持っているか？
			if (argPath[len - 4] != '.') {
				fprintf(stderr,
					"Error : Invalid argument(No extension) [%s]\n", argPath);
				return FALSE;
			}

			// タイプを決める
			ext = &argPath[len - 3];
			if (strcasecmp(ext, "hds") == 0) {
				// HD
				type = 0;
			} else if (strcasecmp(ext, "mos") == 0) {
				// MO
				type = 1;
			} else if (strcasecmp(ext, "iso") == 0) {
				// CD
				type = 2;
			} else {
				// タイプが判別できない
				fprintf(stderr,
					"Error : Invalid argument(file type) [%s]\n", ext);
				return FALSE;
			}
		}

		// コマンド実行
		if (!ProcessCmd(stderr, id, 0, type, argPath)) {
			return FALSE;
		}
	}

	// デバイスリスト表示
	ListDevice(stdout);

	return TRUE;
}

//---------------------------------------------------------------------------
//
//	モニタースレッド
//
//---------------------------------------------------------------------------
static void *MonThread(void *param)
{
	struct sockaddr_in client;
	socklen_t len; 
	int fd;
	FILE *fp;
	BYTE buf[BUFSIZ];
	int i;
	int id;
	int cmd;
	int type;
	char *file;
	BOOL list;

	// 監視準備
	listen(monfd, 1);

	while (1) {
		// 接続待ち
		memset(&client, 0, sizeof(client)); 
		len = sizeof(client); 
		fd = accept(monfd, (struct sockaddr*)&client, &len);
		if (fd < 0) {
			break;
		}

		// コマンド取得
		fp = fdopen(fd, "r+");
		fgets((char *)buf, BUFSIZ, fp);
		buf[strlen((const char*)buf) - 1] = 0;

		// デバイスリスト表示なのか制御コマンドかを判断
		if (strncasecmp((char*)buf, "list", 4) == 0) {
			list = TRUE;
		} else {
			list = FALSE;
			id = (int)(buf[0] - '0');
			cmd = (int)(buf[2] - '0');
			type = (int)(buf[4] - '0');
			file = (char*)&buf[6];
		}

		// バスフリーを見計らってConstructを呼ぶ
		while (phase != BUS::busfree) {
			usleep(500 * 1000);
		}

		if (list) {
			// リスト表示
			ListDevice(fp);
		} else {
			// コマンド実行
			ProcessCmd(fp, id, cmd, type, file);
		}

		// 接続解放
		fclose(fp);
		close(fd);
	}
}

//---------------------------------------------------------------------------
//
//	主処理
//
//---------------------------------------------------------------------------
int main(int argc, char* argv[])
{
	int i;
	DWORD dwBusBak;
	DWORD dwBusIn;
	struct sched_param schparam;

	// バナー出力
	if (!Banner(argc, argv)) {
		exit(0);
	}

	// 初期化
	if (!Init()) {
		fprintf(stderr, "Error : Initializing\n");

		// 恐らくrootでは無い？
		exit(EPERM);
	}

	// 既に起動している？
	if (!bServer) {
		fprintf(stderr, "Error : Already running RaSCSI\n");
		exit(0);
	}

	// 構築
	if (!ParseArgument(argc, argv)) {
		// クリーンアップ
		Cleanup();

		// 引数エラーで終了
		exit(EINVAL);
	}

	// モニタースレッド生成
	bRun = TRUE;
	pthread_create(&monthread, NULL, MonThread, NULL);

	// リセット
	Reset();

	// メインループ準備
	phase = BUS::busfree;
	dwBusBak = bus.Aquire();

	// メインループ
	while(bRun) {
		// バスの入力信号変化検出
		dwBusIn = bus.Aquire();

		// 入力信号変化検出
		if ((dwBusIn & GPIO_INEDGE) == (dwBusBak & GPIO_INEDGE)) {
			usleep(1);
			continue;
		}

		// バスの入力信号を保存
		dwBusBak = dwBusIn;

		// そもそもセレクション信号が無ければ無視
		if (!bus.GetSEL() || bus.GetBSY()) {
			continue;
		}

		// 全コントローラに通知
		for (i = 0; i < CtrlMax; i++) {
			if (!ctrl[i]) {
				continue;
			}

			// セレクションフェーズに移行したターゲットを探す
			if (ctrl[i]->Process() == BUS::selection) {
				// ターゲットのIDを取得
				scsiid = i;

				// セレクションフェーズ
				phase = BUS::selection;

				break;
			}
		}

		// セレクションフェーズが開始されていなければバスの監視へ戻る
		if (phase != BUS::selection) {
			continue;
		}

		// スケジューリングポリシー設定(最優先)
		schparam.sched_priority = sched_get_priority_max(SCHED_FIFO);
		sched_setscheduler(0, SCHED_FIFO, &schparam);

		// バスフリーになるまでループ
		while (bRun) {
			// バスの入力信号変化検出
			dwBusIn = bus.Aquire();

			// 入力信号変化検出
			if ((dwBusIn & GPIO_INEDGE) == (dwBusBak & GPIO_INEDGE)) {
				continue;
			}

			// バスの入力信号を保存
			dwBusBak = dwBusIn;

			// ターゲットへ通知
			phase = ctrl[scsiid]->Process();

			// バスフリーになったら終了
			if (phase == BUS::busfree) {
				break;
			}
		}

		// バスフリーでセッション終了
		scsiid = -1;
		phase = BUS::busfree;
		bus.Reset();

		// スケジューリングポリシー設定(ノーマル)
		schparam.sched_priority = 0;
		sched_setscheduler(0, SCHED_OTHER, &schparam);
	}

	// クリーンアップ
	Cleanup();

	// 終了
	exit(0);
}
