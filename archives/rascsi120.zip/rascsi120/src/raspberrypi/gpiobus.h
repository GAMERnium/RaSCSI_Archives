﻿//---------------------------------------------------------------------------
//
//  SCSI Target Emulator RaSCSI (*^..^*)
//  for Raspberry Pi
//
//  Powered by XM6 TypeG Technorogy.
//  Copyright (C) 2016-2017 GIMONS
//	[ GPIO-SCSIバス ]
//
//---------------------------------------------------------------------------

#if !defined(gpiobus_h)
#define gpiobus_h

//---------------------------------------------------------------------------
//
//	定数宣言
//
//---------------------------------------------------------------------------
#define PERI_BASE1		0x20000000				// RPI1
#define PERI_BASE2		0x3F000000				// RPI2 or 3
#define GPIO_OFFSET		0x200000
#define PADS_OFFSET		0x100000
#define GBLOCK_SIZE		4096
#define GPIO_INPUT		0
#define GPIO_OUTPUT		1
#define GPIO_PULLNONE	0
#define GPIO_PULLDOWN	1
#define GPIO_PULLUP		2
#define GPIO_FSEL_0		0
#define GPIO_FSEL_1		1
#define GPIO_FSEL_2		2
#define GPIO_FSEL_3		3
#define GPIO_SET_0		7
#define GPIO_CLR_0		10
#define GPIO_LEV_0		13
#define GPIO_PUD		37
#define GPIO_CLK_0		38
#define PAD_0_27		11

#define GPIO_INEDGE ((1 << GPIOBUS::pin_bsy) | \
					 (1 << GPIOBUS::pin_sel) | \
					 (1 << GPIOBUS::pin_atn) | \
					 (1 << GPIOBUS::pin_ack) | \
					 (1 << GPIOBUS::pin_rst))

class GPIOBUS : public BUS
{
public:

	// GPIOピンマッピング定義
	enum pin_t {
		pin_dt0 = 10,					// データ0
		pin_dt1 = 11,					// データ1
		pin_dt2 = 12,					// データ2
		pin_dt3 = 13,					// データ3
		pin_dt4 = 14,					// データ4
		pin_dt5 = 15,					// データ5
		pin_dt6 = 16,					// データ6
		pin_dt7 = 17,					// データ7
		pin_par = 18,					// パリティ
		pin_atn = 19,					// ATN
		pin_rst = 20,					// RST
		pin_ack = 21,					// ACK
		pin_req = 22,					// REQ
		pin_msg = 23,					// MSG
		pin_cd = 24,					// CD
		pin_io = 25,					// IO
		pin_bsy = 26,					// BSY
		pin_sel = 27					// SEL
	};

	// 基本ファンクション
	GPIOBUS();
										// コンストラクタ
	virtual ~GPIOBUS();
										// デストラクタ
	BOOL FASTCALL Init();
										// 初期化
	void FASTCALL Reset();
										// リセット
	void FASTCALL Cleanup();
										// クリーンアップ
	void FASTCALL SleepNsec(long nsec);
										// ナノ秒単位のスリープ(精度は120ns程度)
	DWORD FASTCALL Aquire();
										// GPIO信号取り込み
	BOOL FASTCALL GetBSY();
										// BSYシグナル取得
	void FASTCALL SetBSY(BOOL ast);
										// BSYシグナル設定

	BOOL FASTCALL GetSEL();
										// SELシグナル取得
	void FASTCALL SetSEL(BOOL ast);
										// SELシグナル設定

	BOOL FASTCALL GetATN();
										// ATNシグナル取得
	void FASTCALL SetATN(BOOL ast);
										// ATNシグナル設定

	BOOL FASTCALL GetACK();
										// ACKシグナル取得
	void FASTCALL SetACK(BOOL ast);
										// ACKシグナル設定

	BOOL FASTCALL GetRST();
										// RSTシグナル取得
	void FASTCALL SetRST(BOOL ast);
										// RSTシグナル設定

	BOOL FASTCALL GetMSG();
										// MSGシグナル取得
	void FASTCALL SetMSG(BOOL ast);
										// MSGシグナル設定

	BOOL FASTCALL GetCD();
										// CDシグナル取得
	void FASTCALL SetCD(BOOL ast);
										// CDシグナル設定

	BOOL FASTCALL GetIO();
										// IOシグナル取得
	void FASTCALL SetIO(BOOL ast);
										// IOシグナル設定

	BOOL FASTCALL GetREQ();
										// REQシグナル取得
	void FASTCALL SetREQ(BOOL ast);
										// REQシグナル設定

	BYTE FASTCALL GetDAT();
										// データシグナル取得
	void FASTCALL SetDAT(BYTE dat);
										// データシグナル設定

private:
	BOOL FASTCALL GpioInit();
										// GPIO初期化
	void FASTCALL DrvConfig(DWORD drive);
										// Drive Strength設定
	void FASTCALL PinConfig(pin_t pin, int mode);
										// ピン機能設定(入出力設定)
	void FASTCALL PullConfig(pin_t pin, int mode);
										// ピン機能設定(プルアップ/ダウン)
	void FASTCALL PinSigSet(pin_t pin, BOOL ast);
										// ピン出力設定

	BOOL FASTCALL GetSignal(pin_t pin);
										// シグナル取得
	void FASTCALL SetSignal(pin_t pin, BOOL ast);
										// シグナル設定

	volatile DWORD *gpio;				// GPIOレジスタ

	volatile DWORD *pads;				// PADSレジスタ

	DWORD dwGPFSEL[4];					// GPFSEL0-4バックアップ

	DWORD signals;						// バス全信号

	DWORD tblDataBus[256];				// データバス設定テーブル

};

#endif	// gpiobus_h
